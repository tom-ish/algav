package tries_briandais.test;

import java.util.List;

import tools.Tools;
import tries_briandais.BRDprimitives;
import tries_briandais.BRDtree;

public class TestDeleteBRD {

	public static void main(String[] args) {
		String filename = "Samples/exemple_TD.txt";
		String motAsup = "TC";

		List<String> l = Tools.getStringsFromFileBRD(filename);
		BRDtree brd = BRDprimitives.emptyBRD();
		brd = BRDprimitives.addBRD(brd, l);

		//test supression d'un mot dans un arbre
		System.out.println("\n\n============================\n"
				+     "Suprimer un mot dans un arbre\n" +
				"============================\n");
		Tools.deleteThenPrintIfExist(brd, motAsup);
	}

}
