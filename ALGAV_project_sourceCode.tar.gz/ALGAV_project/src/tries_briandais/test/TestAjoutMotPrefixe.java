package tries_briandais.test;

import java.util.List;

import tools.Tools;
import tries_briandais.BRDprimitives;
import tries_briandais.BRDtree;

public class TestAjoutMotPrefixe {

	public static void main(String[] args) {
		String filename = "Samples/exemple_TD_2.txt";;
		BRDtree b = BRDprimitives.emptyBRD();
		List<String> list = Tools.getStringsFromFileBRD(filename);
		
		System.out.println("\n\n=====================\n"
				+     "Liste de mots\n" +
				"=====================\n");
		for(String s : list) System.out.println(s);
		b = BRDprimitives.addBRD(b, list);
		
		System.out.println("\n\n=====================\n"
				+     "Arbre de la Briandais\n" +
				"=====================\n");
		Tools.printBriandais(b, 0);
		
	}

}
