package tries_hybrids.test;

import java.util.List;

import tools.Tools;
import tries_hybrids.HBDadvancedFunctions;
import tries_hybrids.HBDprimitives;
import tries_hybrids.HBDtree;

public class TestTmp {

	public static void main(String[] args) {
		List<String> l = Tools.getStringsFromFileHBD("Samples/exemple_base.txt");
		HBDtree t = null;//new HBDtree('\u0000', Tools.EMPTY, null, null, null);
		t = HBDprimitives.addHBD(t,l);
		//Tools.printHybrid(t);
		
		//System.out.println("azerty"+t.getCar());
		
		//test lister par ordre alphabetique
		System.out.println("\n\n============================\n"
				+     "Lister en ordre alphabetique\n" +
				"============================\n");
		List<String> list = HBDadvancedFunctions.wordList(t);
		for(int i=0; i<list.size(); i++)
			System.out.println(list.get(i));

	}

}
