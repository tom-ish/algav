package tries_briandais;

import java.util.List;

import tools.Tools;

public class BRDprimitives {

	//retourne un briandais vide, '\0' represente le caractere de fin
	public static BRDtree emptyBRD(){
		return new BRDtree('\0', null, null);
	}

	//verifie si l'arbre de la Briandais passé en parametre est vide
	public static boolean isEmpty(BRDtree brd){
		return (brd==null || (brd.key == '\0' 
				&& brd.child == null
				&& brd.next == null));
	}

	//construit un arbre de la Briandais a partir du mot passé en parametre
	public static BRDtree buildBRD(String m){

		if(m.compareTo("\0")==0)
			return emptyBRD();
		else 
			return new BRDtree(Tools.head(m), buildBRD(Tools.tail(m)), null);


	}

	//ajouter le mot passé en parametre à l'arbre passé en parametre
	public static BRDtree addBRD(BRDtree brd, String m){
		//si l'arbre est null
		if(brd==null){
			//si le mot correspond au caractere de fin
			if(m == "\0") 
				//construire un arbre de la briandais vide
				return emptyBRD();
			else //sinon, construire un BRD à partir du mot en parametre 
				return buildBRD(m);
		}

		//si arbre non vide et mot correspond au caractere de fin
		if(m.compareTo("\0")==0){
			//si la cle est le caractere de fin 
			if(brd.getkey()=='\0')
				return brd;
			else{
				return new BRDtree('\0', null, brd);					
			}
		}

		//cas ou le 1er caractere du mot est inferieur a la cle de l'arbre
		if(Tools.head(m).compareTo(brd.getkey())<0){
			//construire un arbre dont la tete est le 1er caractere
			//le fils est construit a partir du mot privé du 1er caractere
			//le suivant est l'arbre initial
			return new BRDtree(Tools.head(m), buildBRD(Tools.tail(m)), brd);

			//cas ou le 1er caractere est superieur a la cle de l'arbre	
		} else if(Tools.head(m).compareTo(brd.getkey())>0){
			//on a le meme arbre initial (cle + fils)
			//mais son suivant est consrtuit en ajoutant 
			//le mot au suivant de l'arbre initial
			return new BRDtree(brd.getkey(), brd.getChild(), addBRD(brd.getNext(),m));
		}

		//cas ou le 1er caractere est le meme que la cle de l'arbre
		else {

			//on construit un arbre a partir de la cle de l'arbre initial
			//le fils correspond a l'ajout du mot, prive de son 1er caractere, au fils de l'arbre initial
			//le suivant est le meme que celui de l'arbre initial
			return new BRDtree(brd.getkey(), addBRD(brd.getChild(), Tools.tail(m)), brd.getNext());
		}
	}

	//ajoute une liste de mots dans un arbre 
	public static BRDtree addBRD(BRDtree brd, List<String> list){
		for(int i=0; i<list.size(); i++){
			brd = addBRD(brd, list.get(i));
			//System.out.println("Le mot " + list.get(i) + " a ete ajouté.");
		}
		return brd;
	}



}
