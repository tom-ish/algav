package tries_hybrids;

import java.util.ArrayList;
import java.util.List;

import tools.Tools;
import tries_briandais.BRDprimitives;
import tries_briandais.BRDtree;

public class HBDcomplexFunctions {

	public static BRDtree hybridToBRD(HBDtree t){

		BRDtree brd1, brd2, brd3;

		if(t==null) return null;

		brd1 = hybridToBRD(t.getInf());

		//si c'est la fin d'un mot, on cree un nouveau briandais
		//avec comme fils un briandais vide
		//et on fait un appel a la fonction de conversion sur le frere du fils
		//avec le fils eq du trie hybrid
		if(t.getVal()==Tools.NOTEMPTY){
			brd2 = new BRDtree(t.getCar(), BRDprimitives.emptyBRD(), null);
			brd2.getChild().setNext(hybridToBRD(t.getEq()));
		}else{
			//sinon on cree un briandais a partir du fils eq 
			//du trie hybrid
			brd2 = new BRDtree(t.getCar(), null, null);
			brd2.setChild(hybridToBRD(t.getEq()));
		}

		//le frere du briandais correspond a la conversion du
		//fils sup du trie hybrid
		brd2.setNext(hybridToBRD(t.getSup()));

		brd3 = brd1;
		while(brd3!=null && brd3.getNext()!=null){
			brd3 = brd3.getNext();
		}

		if(brd3==null){
			return brd2;
		}
		else
			brd3.setNext(brd2);

		return brd1;		

	}

	public static boolean estEquilibre(HBDtree t){
		if (t==null) return true;

		int hinf = HBDadvancedFunctions.height(t.getInf());
		int hsup = HBDadvancedFunctions.height(t.getSup());

		return !(Math.abs(hinf-hsup)>1);
	}
	
	public static HBDtree rotationDroite(HBDtree t){
		HBDtree t_res;
		t_res = t.getInf();
		t.setInf(t_res.getSup());
		t_res.setSup(t);
		
		return t_res;		
	}

	public static HBDtree rotationGauche(HBDtree t){
		HBDtree t_res;
		t_res = t.getSup();
		t.setSup(t_res.getInf());
		t_res.setInf(t);
		
		return t_res;
	}
	
	public static HBDtree equilibrage(HBDtree t){
		if (t == null) return t;
		
		//on fait l equilibrage pour chacuns des fils inf, eq et sup
		t.setInf(equilibrage(t.getInf()));
		t.setEq(equilibrage(t.getEq()));
		t.setSup(equilibrage(t.getSup()));
		
		//verification de l equilibrage
		int hinf = HBDadvancedFunctions.height(t.getInf());
		int hsup = HBDadvancedFunctions.height(t.getSup());
		int hdif = hinf-hsup;
		
		if(hdif>=2){
			//on verifie si le fils inferieur a besoin d'une rotation gauche
			//On est dans le cas ou on fait une rotation gauche droite
			int dif_inf = HBDadvancedFunctions.height(t.getInf().getInf()) - 
						  HBDadvancedFunctions.height(t.getInf().getSup());
			if(dif_inf<=-1)
				t.setInf(rotationGauche(t.getInf()));
			
			t = rotationDroite(t);
		}
		else if(hdif<=-2){
			//on verifie si le fils superieur a besoin d'une rotation droite
			//On est dans le cas ou on fait une rotation droite gauche
			int dif_sup = HBDadvancedFunctions.height(t.getSup().getInf()) - 
					  	  HBDadvancedFunctions.height(t.getSup().getSup());
			if(dif_sup >=1)
				t.setSup(rotationDroite(t.getSup()));
			
			t = rotationGauche(t);
		}
		return t;
		
	}
	
	public static HBDtree equilibrageNaif(HBDtree t){

		HBDtree tres = null;
		//si arbre null pas besoin d'équilibrer
		if(t==null) return null;

		//verifier si l'arbre est equilibré
		//		if(estEquilibre(t))
		//			return t;
		//on recupere les mots contenu dans l'arbre
		List<String> l = new ArrayList<String>();
		l = HBDadvancedFunctions.wordList(t);

		//on prend le mot du milieu 
		int mid = l.size()/2;

		//on rajoute tous les mots superieurs
		tres = HBDprimitives.addHBD(tres, l.subList(mid, l.size()));

		//on rajoute tous les mots inférieurs
		tres = HBDprimitives.addHBD(tres, l.subList(0, mid-1));

		return tres;
	}
	
	public static HBDtree reequilibrage(HBDtree t) {
		if(t == null) return null;

		Integer hauteurGauche = HBDadvancedFunctions.height(t.getInf());
		Integer hauteurDroite = HBDadvancedFunctions.height(t.getSup());

		if(Math.abs(hauteurGauche - hauteurDroite) > 1){
			// si le fils gauche est plus grand que le fils droit
			if(hauteurGauche - hauteurDroite < 1) {
				t = rotationDroite(t);
			}
			// si le fils gauche est plus petit que le fils droit
			if(hauteurGauche - hauteurDroite > 1) {
				t = rotationGauche(t);
			}
			reequilibrage(t);
		}
		return t;
	}
}
