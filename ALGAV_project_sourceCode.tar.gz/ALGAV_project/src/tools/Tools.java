package tools;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import tries_briandais.BRDadvancedFunctions;
import tries_briandais.BRDprimitives;
import tries_briandais.BRDtree;
import tries_hybrids.HBDadvancedFunctions;
import tries_hybrids.HBDtree;

public class Tools {

	public static String eps = "\u03B5";
	public static char EMPTY = '0';
	public static char NOTEMPTY = '1';
	public static int cpt=0;

	public static Character head(String m){
		return m.charAt(0);
	}

	public static String tail(String m){

//		char[] dst = new char[m.length()-1];
//		int j=1;
//
//		for(int i=0; i<dst.length; i++)
//			dst[i] = m.charAt(j++);
//
//		return new String(dst);
		
		return m.substring(1);


	}

	//fonction qui stock dans une liste chaque mot present dans un fichier
	public static List<String> getStringsFromFileBRD(String file){
		List<String> strings = new ArrayList<String>();

		Scanner scanner;
		try {
			scanner = new Scanner(new FileReader(file));

			while (scanner.hasNext()) {
				//ajoute a la fin de chaque mot le caractere '\0'
				strings.add(scanner.next()+'\0');
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		return strings;
	}

	public static List<String> getStringsFromFileHBD(String file){
		List<String> strings = new ArrayList<String>();

		Scanner scanner;
		try {
			scanner = new Scanner(new FileReader(file));

			while (scanner.hasNext()) {
				strings.add(scanner.next());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		return strings;
	}

	public static void printBriandais(BRDtree brd, int height){
		if(brd == null)
			return;
		if(brd.getkey()=='\0')
			System.out.print(eps);
		else
			System.out.print(brd.getkey());

		printBriandais(brd.getChild(), height+1);

		if(brd.getNext()!=null){	
			System.out.println();
			for(int i=0; i<height-1; i++)
				System.out.print(" ");
			if(height>0)
				System.out.print("|");
		}
		printBriandais(brd.getNext(),height);

	}

	public static  void printHybrid(HBDtree t){
		if(t == null)
			return;
		if(t.getVal()!=EMPTY)
			System.out.print(t.getCar()+" "+(cpt++)+"\n");
		else System.out.print(t.getCar());
		printHybrid(t.getInf());
		printHybrid(t.getEq());
		printHybrid(t.getSup());
	}

	public static void deleteThenPrintIfExist(BRDtree t, String m){
		if(BRDadvancedFunctions.search(t, m)){
			System.out.println("===== Liste de mots contenu dans l'arbre initial =====");
			List<String> list1 = BRDadvancedFunctions.wordList(t);
			for(int i=0; i<list1.size(); i++)
				System.out.println(i+1 +".	"+list1.get(i));

			t = BRDadvancedFunctions.delete(t, m);

			System.out.println("\n===== Liste de Mots apres supression du mot :"+ m +" =====");
			list1 = BRDadvancedFunctions.wordList(t);
			for(int i=0; i<list1.size(); i++)
				System.out.println(i+1 +".	"+list1.get(i));
		}
		else
			System.out.println("Le mot \""+ m +"\" n'existe pas dans l'arbre.");
	}

	public static void deleteThenPrintIfExist(HBDtree t, String m){
		if(HBDadvancedFunctions.search(t, m)){
			System.out.println("===== Liste de mots contenu dans l'arbre initial =====");
			List<String> list1 = HBDadvancedFunctions.wordList(t);
			for(int i=0; i<list1.size(); i++)
				System.out.println(i+1 +".	"+list1.get(i));

			t = HBDadvancedFunctions.delete(t, m);

			System.out.println("\n===== Liste de Mots apres supression du mot :"+ m +" =====");
			list1 = HBDadvancedFunctions.wordList(t);
			for(int i=0; i<list1.size(); i++)
				System.out.println(i+1 +".	"+list1.get(i));
		}
		else
			System.out.println("Le mot \""+ m +"\" n'existe pas dans l'arbre.");
	}
	
	public static List<String> getFileNamesFromDirectory(String dir){
		List<String> list = new ArrayList<String>();
		File rep = new File(dir);
		for(File f : rep.listFiles()){
			if(f.isFile())
				list.add(f.getName());
		}
		return list;
	}
	
	public static BRDtree createBRDfromFile(String filename){
		BRDtree t= null;
		List<String> l = getStringsFromFileBRD(filename);
		for(String s : l)
			t = BRDprimitives.addBRD(t, s);
		return t;
	}
	public static List<BRDtree> createListOfBRD(List<String> fileList){
		List<BRDtree> l_brd = new ArrayList<>();
		for(String file : fileList){
			l_brd.add(createBRDfromFile(file));
		}
		return l_brd;
	}
}
