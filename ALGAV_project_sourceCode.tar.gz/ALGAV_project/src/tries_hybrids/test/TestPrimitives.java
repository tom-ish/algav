package tries_hybrids.test;

import tools.Tools;
import tries_hybrids.HBDprimitives;
import tries_hybrids.HBDtree;

public class TestPrimitives {
	public static void main(String[] args){
		String m = "loup";
		String m1 = "chat";
		HBDtree t = HBDprimitives.buildHBD(m);
		t = HBDprimitives.addHBD(t, m1);
		Tools.printHybrid(t);
	}
}
