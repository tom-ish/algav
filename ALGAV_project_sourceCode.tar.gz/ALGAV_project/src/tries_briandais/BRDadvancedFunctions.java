package tries_briandais;

import java.util.ArrayList;
import java.util.List;

import tools.Tools;

public class BRDadvancedFunctions {
	public static boolean search(BRDtree t, String m){
		//par defaut recherche mot vide renvoie faux
		if(m=="") return false;

		//on rajoute le caractere de fin au mot en parametre
		m = m+'\0';

		if(t==null)
			return false;
		if(t.getkey() == '\0'){
			if(Tools.head(m)=='\0')
				return true;
			return search(t.getNext(),m);
		}		
		if(Tools.head(m)=='\0')
			return false;
		if(t.getkey()==Tools.head(m))
			return search(t.getChild(),Tools.tail(m));
		if(t.getkey().compareTo(Tools.head(m))<0)
			return search(t.getNext(),m);
		return false;
	}

	public static int wordCount(BRDtree t){
		if(t == null)
			return 0;
		if(t.getkey()=='\0')
			return 1 + wordCount(t.getNext());
		return wordCount(t.getChild()) + wordCount(t.getNext());
	}

	private static void wordListRec(BRDtree t, List<String> list, String m){
		if(t == null) return;
		String nm = m;		

		nm = nm+t.getkey();

		if(t.getkey()=='\0') list.add(nm);
		wordListRec(t.getChild(), list, nm);
		wordListRec(t.getNext(), list, m);
	}

	public static List<String> wordList(BRDtree t){
		List<String> l = new ArrayList<String>();
		wordListRec(t,l,"");
		return l;
	}

	public static int NilCount(BRDtree t){
		if(t==null) return 1;
		return NilCount(t.getChild()) + NilCount(t.getNext());
	}

	public static int height(BRDtree t){
		if(t==null) return 0;
		return Math.max(height(t.getChild())+1, height(t.getNext()));
	}

	public static int averageDepth(BRDtree t){
		int moy=0;
		int nb_next=0;
		int h=0;
		BRDtree tree = t;

		while(tree!=null){
			h=height(tree.getChild());
			nb_next++;
			moy += h+1;
			tree = tree.getNext();
		}
		return (int)(moy/nb_next);		
	}

	public static int prefix(BRDtree t, String m){	
		if(t == null) return 0;
		if(m.compareTo("")==0) return wordCount(t);
		if(Tools.head(m).compareTo(t.key)<0)
			return 0;
		else if(Tools.head(m).compareTo(t.key)>0)
			return prefix(t.getNext(),m);
		else 
			return prefix(t.getChild(),Tools.tail(m));

	}

	public static BRDtree delete(BRDtree t, String m){
		if(t==null) return null;
		//on rajoute en fin de mot le caractère de fin
		m = m+'\0';
		//if(BRDprimitives.isEmpty(t) && m.compareTo("")==0) return t.getNext();
		//cas ou le mot a supprimer est prefixe d'un autre
		if(t.getkey() == Tools.head(m)){			
			BRDtree child = delete(t.getChild(),Tools.tail(m));
			if(child == null) return t.getNext();
			else return new BRDtree(t.getkey(), child, t.getNext());
		}
//		else if(t.getkey().compareTo(Tools.head(m))>0){
//			return t;
//		}
		else
			return new BRDtree(t.getkey(), t.getChild(), delete(t.getNext(),m));
	}
	
	public static BRDtree delete(BRDtree t, List<String> l){
		for(String s : l)
			t = delete(t,s);
		return t;
	}
}

