package tries_briandais.test;

import java.util.List;

import tools.Tools;
import tries_briandais.BRDprimitives;
import tries_briandais.BRDtree;

public class TestPrimitivesFichier {

	public static void main(String[] args) {
		List<String> l = Tools.getStringsFromFileBRD("Samples/exemple_base.txt");
		BRDtree brd = BRDprimitives.emptyBRD();
		
		brd = BRDprimitives.addBRD(brd, l);
		Tools.printBriandais(brd, 0);
	}

}
