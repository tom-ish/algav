package tries_briandais;

import tools.Tools;
import tries_hybrids.HBDtree;

public class BRDcomplexFunctions {

	public static BRDtree fusion(BRDtree t1, BRDtree t2){
		if(t1==null && t2==null) return null;
		if(t1==null) return t2;
		if(t2==null) return t1;

		if(t1.getkey().compareTo(t2.getkey())<0)
			return new BRDtree(t1.getkey(), t1.getChild(), fusion(t1.getNext(),t2));
		else if(t1.getkey().compareTo(t2.getkey())>0)
			return new BRDtree(t2.getkey(), t2.getChild(), fusion(t1,t2.getNext()));
		else {
			return new BRDtree(t1.getkey(),	
					fusion(t1.getChild(), t2.getChild()),
					fusion(t1.getNext(), t2.getNext()));
		}
	}

	public static HBDtree brdToHybrid(BRDtree t){
		HBDtree inf = null, eq = null, sup = null;
		char val = Tools.EMPTY;

		if(t==null || BRDprimitives.isEmpty(t)) return null;

		if(t.getChild()!=null){
			if(t.getChild().getkey()=='\0'){
				val = Tools.NOTEMPTY;
				eq = brdToHybrid(t.getChild().getNext());
			}else{
				eq = brdToHybrid(t.getChild());
			}
		}
		if(t.getNext()!=null){
			sup = brdToHybrid(t.getNext());
		}

		return new HBDtree(t.getkey(), val, inf, eq, sup);

	}



}
