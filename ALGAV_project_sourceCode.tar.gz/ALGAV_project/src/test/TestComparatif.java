package test;

import java.util.ArrayList;
import java.util.List;

import tools.Tools;
import tries_briandais.BRDadvancedFunctions;
import tries_briandais.BRDcomplexFunctions;
import tries_briandais.BRDprimitives;
import tries_briandais.BRDtree;
import tries_hybrids.HBDadvancedFunctions;
import tries_hybrids.HBDprimitives;
import tries_hybrids.HBDtree;

public class TestComparatif {

	public static void main(String[] args) {
		String dir = "shakespeare";
		String sup = "shakespeare/john.txt";
		List<List<String>> listOfNames = new ArrayList<List<String>>();
		List<String> l_fileDirTmp = Tools.getFileNamesFromDirectory(dir);
		
		//liste contenant les noms des fichiers precede du nom de repertoire les contenants
		List<String> l_fileDir = new ArrayList<>();
		for(String s : l_fileDirTmp) l_fileDir.add(dir+"/"+s);
		
		List<String> l_brd = Tools.getStringsFromFileBRD(sup);
		List<String> l_hbd = Tools.getStringsFromFileHBD(sup);
		
		//liste contenant les arbres BRD pour la fusion
		List<BRDtree> l_brdTree = Tools.createListOfBRD(l_fileDir);
		
		
		l_fileDir.sort(null);
		
		

		for(String filename : l_fileDir){
			//cette liste contient des listes de mots de chaque oeuvre
			listOfNames.add(Tools.getStringsFromFileBRD(filename));
		}
		
		//Tools.printBriandais(b, 0);
		System.out.println("====================================\n"
				+     "Ajout de l'ensemble des oeuvres de  "
				+ "Shakespeare\n      par fusions successives\n" +
				"====================================");
		long debut = System.currentTimeMillis();
		BRDtree b = null;
		b=BRDcomplexFunctions.fusion(l_brdTree.get(0), l_brdTree.get(1));
		for(int i=2;i<l_brdTree.size(); i++ ){
			b = BRDcomplexFunctions.fusion(b, l_brdTree.get(i));
		}
		System.out.println("Briandais :Temps d'ajout de toutes les oeuvres de Shakespeare :"+ (System.currentTimeMillis()-debut)+" ms");
		System.out.println("nombre de mots total: "+ BRDadvancedFunctions.wordCount(b));
		
		
		System.out.println("\n====================================\n"
				+     "Ajout de l'ensemble des oeuvres de  "
				+ "Shakespeare\n      par ajouts successifs\n" +
				"====================================");
		 debut = System.currentTimeMillis();
		 b = null;
		for(List<String> list : listOfNames){
			b = BRDprimitives.addBRD(b, list);
		}
		System.out.println("Briandais :Temps d'ajout de toutes les oeuvres de Shakespeare :"+ (System.currentTimeMillis()-debut)+" ms");
		System.out.println("nombre de mots total: "+ BRDadvancedFunctions.wordCount(b));
		
		debut = System.currentTimeMillis();
		HBDtree th = null;
		for(List<String> list : listOfNames){
			th = HBDprimitives.addHBD(th, list);
		}
		
		System.out.println("Trie Hybrid :Temps d'ajout de toutes les oeuvres de Shakespeare :"+ (System.currentTimeMillis()-debut)+" ms");
		System.out.println("nombre de mots total: "+ HBDadvancedFunctions.wordCount(th));
		
		System.out.println("\n====================================\n"
				+"Profondeur de chacune des structure"
				+"\n====================================");
		System.out.println("Hauteur Briandais: "+ BRDadvancedFunctions.height(b));
		System.out.println("Profondeur moyenne arbre de la Briandais: "+ BRDadvancedFunctions.averageDepth(b));
		System.out.println("Hauteur Briandais: "+ HBDadvancedFunctions.height(th));
		System.out.println("Profondeur moyenne trie Hybride: "+ HBDadvancedFunctions.averageDepth(th));
		
		System.out.println("\n====================================\n"
				+"Recherche du mot would"
				+"\n====================================");
		debut = System.nanoTime();
		boolean search = BRDadvancedFunctions.search(b,"would");
		System.out.println("Briandais :Temps de recherche du mot would :"+ (System.nanoTime()-debut)+" ns"+
		",\nrésultat de la recherche: "+search);
		
		debut = System.nanoTime();
		search = HBDadvancedFunctions.search(th,"would");
		System.out.println("Hybride :Temps de recherche du mot would :"+ (System.nanoTime()-debut)+" ns"+
		",\nrésultat de la recherche: "+search);
		
		System.out.println("\n====================================\n"
				+"Ajout du mot mystique"
				+"\n====================================");
		debut = System.nanoTime();
		b = BRDprimitives.addBRD(b, "mysthique\0");
		System.out.println("Briandais :Temps d'ajout :"+ (System.nanoTime()-debut)+" ns");
		
		debut = System.nanoTime();
		th = HBDprimitives.addHBD(th, "mysthique");
		System.out.println("Hybride :Temps d'ajout :"+ (System.nanoTime()-debut)+" ns");
		
		
		System.out.println("\n====================================\n"
				+"supression de l'oeuvres john"
				+"\n====================================");
		debut = System.currentTimeMillis();
		b = BRDadvancedFunctions.delete(b, l_brd);
		System.out.println("Briandais :Temps de supression de l'oeuvre john: "+ (System.currentTimeMillis()-debut)+" ms");
		debut = System.currentTimeMillis();
		th = HBDadvancedFunctions.delete(th, l_hbd);
		System.out.println("Hybride :Temps de supression de l'oeuvre john: "+ (System.currentTimeMillis()-debut)+" ms");
		
		System.out.println("\n====================================\n"
				+"supression du mot sixth"
				+"\n====================================");
		debut = System.nanoTime();;
		b = BRDadvancedFunctions.delete(b, "sixth");
		System.out.println("Briandais :Temps de supression du mot sixth: "+ (System.nanoTime()-debut)+" ns");
		debut = System.nanoTime();
		th = HBDadvancedFunctions.delete(th, "sixth");
		System.out.println("Hybride :Temps de supression du mot sixth: "+ (System.nanoTime()-debut)+" ns");
		
	}

}
