package tries_hybrids.test;

import java.util.List;

import tools.Tools;
import tries_hybrids.HBDadvancedFunctions;
import tries_hybrids.HBDprimitives;
import tries_hybrids.HBDtree;

public class TestHBDAdvancedPrimitives {

	public static void main(String[] args) {
		String filename = "Samples/exemple_base.txt";
		String mot = "dactylo";
		String prefix = "dactylo";
		String motAsup = "dactylo";

		//test affichage arbre
		List<String> l = Tools.getStringsFromFileHBD(filename);
		HBDtree t = null;
		t = HBDprimitives.addHBD(t, l);
		System.out.println("\n\n=====================\n"
				+     "Trie hybride\n" +
				"=====================\n");
		//Tools.printHybrid(t);

		//test recherche d'un mot
		System.out.println("\n\n=====================\n"
				+     "Recherche d'un mot\n" +
				"=====================\n");
		boolean b = HBDadvancedFunctions.search(t, mot);
		System.out.println("Recherche du mot: "+mot +"\nResultat: "+b);

		//test comptage de mots
		System.out.println("\n\n=====================\n"
				+     "Comptage des mots\n" +
				"=====================\n");
		System.out.println("nombre de mots : "+ HBDadvancedFunctions.wordCount(t));

		//test lister par ordre alphabetique
		System.out.println("\n\n============================\n"
				+     "Lister en ordre alphabetique\n" +
				"============================\n");
		List<String> list = HBDadvancedFunctions.wordList(t);
		for(int i=0; i<list.size(); i++)
			System.out.println(i+1+".	"+list.get(i));

		//test comptage des pointeur null
		System.out.println("\n\n============================\n"
				+     "Comptage des pointeurs null\n" +
				"============================\n");
		System.out.println("Nombre de pointeurs vers Nil: "+HBDadvancedFunctions.NilCount(t));

		//test hauteur 
		System.out.println("\n\n============================\n"
				+     "Hauteur de l'arbre\n" +
				"============================\n");
		System.out.println("La hauteur de l'arbre est: "+ HBDadvancedFunctions.height(t));

		//test profondeur moyenne
		System.out.println("\n\n============================\n"
				+     "Profondeur moyenne des feuilles\n" +
				"============================\n");
		System.out.println("la profondeur moyenne des feuilles est: "+HBDadvancedFunctions.averageDepth(t));

		//test prefixe
		System.out.println("\n\n============================\n"
				+     "Nombre de mots prefixes\n" +
				"============================\n");
		System.out.println("Le nombre de mots prefixe du mot \""+prefix+"\" est :"+ HBDadvancedFunctions.prefix(t, prefix));

		//test supression d'un mot dans un arbre
		System.out.println("\n\n============================\n"
				+     "Suprimer un mot dans un arbre\n" +
				"============================\n");
		Tools.deleteThenPrintIfExist(t, motAsup);
	}

}
