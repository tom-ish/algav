package tries_briandais.test;

import java.util.List;

import tools.Tools;
import tries_briandais.BRDcomplexFunctions;
import tries_briandais.BRDprimitives;
import tries_briandais.BRDtree;
import tries_hybrids.HBDtree;

public class TestBRDcomplexFunctions {

	public static void main(String[] args) {
		String filename = "Samples/exemple_TD.txt";
		String filename2 = "Samples/exemple_TD_2.txt";
		List<String> l = Tools.getStringsFromFileBRD(filename);
		List<String> l2 = Tools.getStringsFromFileBRD(filename2);

		BRDtree brd = BRDprimitives.emptyBRD();
		BRDtree brd1 = BRDprimitives.emptyBRD();
		BRDtree brd2 = BRDprimitives.emptyBRD();
		brd = BRDprimitives.addBRD(brd, l);
		brd1 = BRDprimitives.addBRD(brd2, l2);
				
		System.out.println("====================================\n"
				+     "Test fusion 2 arbres de la Briandais\n" +
				"====================================");
		System.out.println("\n=====================\n"
				+     "Arbre de la Briandais 1\n" +
				"=====================\n");
		Tools.printBriandais(brd, 0);

		System.out.println("\n\n=====================\n"
				+     "Arbre de la Briandais 2\n" +
				"=====================\n");
		Tools.printBriandais(brd1, 0);
		
		System.out.println("\n\n=====================\n"
				+     "Arbre apres fusion\n" +
				"=====================\n");
		brd2 = BRDcomplexFunctions.fusion(brd, brd1);
		Tools.printBriandais(brd2, 0);
		
		System.out.println("\n\n====================================\n"
				+     "Test conversion d'un arbre de la \n"
				+ "Briandais vers un trie hybride\n" +
				"====================================");
		System.out.println("\n=====================\n"
				+     "Arbre de la Briandais à convertir\n" +
				"=====================\n");
		Tools.printBriandais(brd, 0);
		System.out.println("\n\n=====================\n"
				+     "Trie Hybrid\n" +
				"=====================\n");
		HBDtree th = null;
		th = BRDcomplexFunctions.brdToHybrid(brd);
		Tools.printHybrid(th);

	}

}
