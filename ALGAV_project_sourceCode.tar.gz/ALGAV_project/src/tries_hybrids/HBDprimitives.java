package tries_hybrids;

import java.util.List;

import tools.Tools;

public class HBDprimitives {

	public static HBDtree buildHBD(String m){
		int length = m.length();
		HBDtree t = null;
		if(length == 0)
			return null;
		t = new HBDtree(m.charAt(length-1), Tools.NOTEMPTY, null, null, null);
		for(int i=(length-2); i>=0; i--){
			t = new HBDtree(m.charAt(i), Tools.EMPTY, null, t, null);
		}
		return t;
	}

	public static HBDtree addHBD(HBDtree th, String m){

		if(th==null) th = buildHBD(m);

//		if(m.length()==1 ){
//			th.setVal(Tools.NOTEMPTY);
//			//return th;
//		}
		if(Tools.head(m).compareTo(th.getCar())<0){
			th.setInf(addHBD(th.getInf(), m));
		}
		else if(Tools.head(m).compareTo(th.getCar())>0){
			th.setSup(addHBD(th.getSup(),m));
		}
		else{
			if(m.length()==1){
				th.setVal(Tools.NOTEMPTY);
			}else{
				th.setEq(addHBD(th.getEq(),Tools.tail(m)));
			}
		}
		return th;
	}

	public static HBDtree addHBD(HBDtree t, List<String> list){
		for(int i=0; i<list.size(); i++){
			t = addHBD(t, list.get(i));
		}
		return t;
	}


}
