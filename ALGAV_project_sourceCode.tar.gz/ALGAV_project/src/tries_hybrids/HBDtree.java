package tries_hybrids;

public class HBDtree {
	
	protected Character car;
	protected Character val;
	protected HBDtree inf;
	protected HBDtree eq;
	protected HBDtree sup;
	
	public HBDtree(Character car, Character val, HBDtree inf, HBDtree eq, HBDtree sup) {
		super();
		this.car = car;
		this.val = val;
		this.inf = inf;
		this.eq = eq;
		this.sup = sup;
	}
	
	public Character getCar() {
		return car;
	}
	public void setCar(Character car) {
		this.car = car;
	}
	public Character getVal() {
		return val;
	}
	public void setVal(Character val) {
		this.val = val;
	}
	public HBDtree getInf() {
		return inf;
	}
	public void setInf(HBDtree inf) {
		this.inf = inf;
	}
	public HBDtree getEq() {
		return eq;
	}
	public void setEq(HBDtree eq) {
		this.eq = eq;
	}
	public HBDtree getSup() {
		return sup;
	}
	public void setSup(HBDtree sup) {
		this.sup = sup;
	}
	
	public String toString(){
		return "";
	}
	
}
