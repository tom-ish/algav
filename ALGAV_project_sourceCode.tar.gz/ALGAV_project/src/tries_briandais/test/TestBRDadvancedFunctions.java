package tries_briandais.test;

import java.util.List;

import tools.Tools;
import tries_briandais.BRDadvancedFunctions;
import tries_briandais.BRDprimitives;
import tries_briandais.BRDtree;

public class TestBRDadvancedFunctions {

	public static void main(String[] args) {
		String filename = "Samples/exemple_base.txt";
		//String filename = "shakespeare/titus.txt";
		String mot = "dactylo";
		String prefix = "dactylo";
		String motAsup = "dactylo";

		//test affichage arbre
		List<String> l = Tools.getStringsFromFileBRD(filename);
		BRDtree brd = null;
		brd = BRDprimitives.addBRD(brd, l);
		System.out.println("\n\n=====================\n"
				+     "Arbre de la Briandais\n" +
				"=====================\n");
		Tools.printBriandais(brd, 0);

		//test recherche d'un mot
		System.out.println("\n\n=====================\n"
				+     "Recherche d'un mot\n" +
				"=====================\n");
		boolean b = BRDadvancedFunctions.search(brd, mot);
		System.out.println("Recherche du mot: "+mot +"\nResultat: "+b);

		//test comptage de mots
		System.out.println("\n\n=====================\n"
				+     "Comptage des mots\n" +
				"=====================\n");
		System.out.println("nombre de mots : "+ BRDadvancedFunctions.wordCount(brd));

		//test lister en ordre alphabetique
		System.out.println("\n\n============================\n"
				+     "Lister en ordre alphabetique\n" +
				"============================\n");
		List<String> list = BRDadvancedFunctions.wordList(brd);
		for(int i=0; i<list.size(); i++)
			System.out.println(list.get(i));

		//test comptage des pointeur null
		System.out.println("\n\n============================\n"
				+     "Comptage des pointeurs null\n" +
				"============================\n");
		System.out.println("Nombre de pointeurs vers Nil: "+BRDadvancedFunctions.NilCount(brd));

		//test hauteur 
		System.out.println("\n\n============================\n"
				+     "Hauteur de l'arbre\n" +
				"============================\n");
		System.out.println("La hauteur de l'arbre est: "+ BRDadvancedFunctions.height(brd));

		//test profondeur moyenne
		System.out.println("\n\n============================\n"
				+     "Profondeur moyenne des feuilles\n" +
				"============================\n");
		System.out.println("la profondeur moyenne des feuilles est: "+BRDadvancedFunctions.averageDepth(brd));

		//test prefixe
		System.out.println("\n\n============================\n"
				+     "Nombre de prefixes d'un mot\n" +
				"============================\n");
		System.out.println("Le nombre de prefixe du mot \""+prefix+"\" est :"+ BRDadvancedFunctions.prefix(brd, prefix));

		//test supression d'un mot dans un arbre
		System.out.println("\n\n============================\n"
				+     "Suprimer un mot dans un arbre\n" +
				"============================\n");
		Tools.deleteThenPrintIfExist(brd, motAsup);
		
	}	

}
