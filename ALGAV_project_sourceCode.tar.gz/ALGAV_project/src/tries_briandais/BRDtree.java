package tries_briandais;


public class BRDtree {

	protected Character key;
	protected BRDtree child;
	protected BRDtree next;

	public BRDtree(Character key, BRDtree child,
			BRDtree next) {
		super();
		this.key = key;
		this.child = child;
		this.next = next;
	}

	public Character getkey() {
		return key;
	}

	public void setkey(Character key) {
		this.key = key;
	}

	public BRDtree getChild() {
		return child;
	}

	public void setChild(BRDtree child) {
		this.child = child;
	}

	public BRDtree getNext() {
		return next;
	}

	public void setNext(BRDtree next) {
		this.next = next;
	}

}
