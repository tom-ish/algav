package tries_hybrids;

import java.util.ArrayList;
import java.util.List;

import tools.Tools;

public class HBDadvancedFunctions {
	public static boolean search(HBDtree t, String m){
		if(t == null) return false;
		else{
			int n = m.length();
			if(n==1 && Tools.head(m).compareTo(t.getCar())==0){
				if(t.getVal()==Tools.NOTEMPTY) 
					return true;
				else 
					return false;
			}
			else {
				if(Tools.head(m).compareTo(t.getCar())<0)
					return search(t.getInf(),m);
				else if(Tools.head(m).compareTo(t.getCar())>0)
					return search(t.getSup(),m);
				else 
					return search(t.getEq(), Tools.tail(m));
			}
		}
	}

	public static boolean search2(HBDtree t, String m){
		if(t==null) return false;
		if(m.compareTo("")==0){
			if(t.getVal()==Tools.NOTEMPTY) 
				return true;
			else 
				return false;
		}
		else {
			if(Tools.head(m).compareTo(t.getCar())<0)
				return search(t.getInf(),m);
			else if(Tools.head(m).compareTo(t.getCar())>0)
				return search(t.getSup(),m);
			else 
				return search(t.getEq(), Tools.tail(m));
		}
	}


	public static int wordCount(HBDtree t){
		if(t == null) return 0;
		if(t.getVal()==Tools.NOTEMPTY)
			return 1 + wordCount(t.getEq()) + wordCount(t.getInf()) + wordCount(t.getSup());
		else
			return wordCount(t.getEq()) + wordCount(t.getInf()) + wordCount(t.getSup());
	}

	private static void wordListRec(HBDtree t, List<String> list, String m){
		if(t==null) return;
		String nm = m;
		wordListRec(t.getInf(), list, nm);
		nm = nm + t.getCar();
		if(t.getVal()==Tools.NOTEMPTY)
			list.add(nm);
		wordListRec(t.getEq(), list, nm);
		nm = nm.substring(0, nm.length()-1);
		wordListRec(t.getSup(), list, nm);

	}

	public static List<String> wordList(HBDtree t){
		List<String> l = new ArrayList<String>();
		wordListRec(t, l, "");
		return l;
	}

	public static int NilCount(HBDtree t){
		if(t==null) return 1;
		return NilCount(t.getInf()) + NilCount(t.getEq()) + NilCount(t.getSup());
	}

	public static int height(HBDtree t){
		if(t==null) return 0;
		return 1 + Math.max(Math.max(height(t.getInf()), height(t.getEq())),height(t.getSup()));
	}

	public static int averageDepth(HBDtree t){
		if(t==null) return 0;
		return (int)((height(t.getInf())+height(t.getEq())+height(t.getSup()))/3);
	}

	public static int prefix(HBDtree t, String m){	
		if(t==null) return 0;
		int n = m.length();
		if(n==1 && Tools.head(m).compareTo(t.getCar())==0){
			if(t.getVal()==Tools.NOTEMPTY)
				return wordCount(t);
		}
		if(Tools.head(m).compareTo(t.getCar())<0)
			return prefix(t.getInf(),m);
		else if(Tools.head(m).compareTo(t.getCar())>0)
			return prefix(t.getSup(),m);
		else
			return prefix(t.getEq(),Tools.tail(m));
	}

	//	public static HBDtree delete(HBDtree t, String m){
	//		if(t.getInf()==null && t.getSup()==null) return null;
	//		else if(t.getInf()==null){
	//			HBDtree tmp = t.getSup();
	//			t.setCar(tmp.getCar());
	//			t.setVal(tmp.getVal());
	//			t.setInf(tmp.getInf());
	//			t.setEq(tmp.getEq());
	//			t.setSup(tmp.getSup());
	//			return t;
	//		}else if(t.getSup()==null){
	//			HBDtree tmp = t.getInf();
	//			t.setCar(tmp.getCar());
	//			t.setVal(tmp.getVal());
	//			t.setInf(tmp.getInf());
	//			t.setEq(tmp.getEq());
	//			t.setSup(tmp.getSup());
	//			return t;
	//		}else{
	//			HBDtree th
	//		}
	//	}
	public static HBDtree delete(HBDtree t, String m){
		if(t==null) return null;
		else if(m.compareTo("")==0){
			if(t.getVal()==Tools.NOTEMPTY)
				if(t.getEq() !=null)
					t.setVal(Tools.EMPTY);
				else if(t.getInf()!=null){
					t.setVal(Tools.EMPTY);
					t.setEq(t.getInf());
					t.setInf(null);
				}
				else if(t.getSup()!=null){
					t.setVal(Tools.EMPTY);
					t.setEq(t.getSup());
					t.setSup(null);
				}
				else
					t=null;
			return t;
		}
		else {
			if(Tools.head(m).compareTo(t.getCar())<0)
				t.setInf(delete(t.getInf(), m));
			else if(Tools.head(m).compareTo(t.getCar())>0)
				t.setSup(delete(t.getSup(), m));
			else
				t.setEq(delete(t.getEq(), Tools.tail(m)));
			if(t.getInf()==null	&& t.getEq()==null && t.getSup()==null)
				t=null;
			else if(t.getEq()==null && t.getInf()!=null){
				t.setEq(t.getInf());
				t.setInf(null);
			}
			else if(t.getEq()==null	&& t.getSup()!=null){
				t.setEq(t.getSup());
				t.setSup(null);
			}			
			return t;
		}

	}

	public static HBDtree delete(HBDtree t, List<String> l){
		for(String s : l)
			t=delete(t,s);
		return t;
	}

}
