package tries_briandais.test;

import tools.Tools;
import tries_briandais.BRDprimitives;
import tries_briandais.BRDtree;

public class TestPrimitives {

	public static void main(String[] args) {
		String m1 = "AA\0";
		String m2 = "AC\0";
		String m3 = "TCA\0";
		String m4 = "TC\0";
		BRDtree t = BRDprimitives.emptyBRD();
		t = BRDprimitives.addBRD(t, m1);
		t = BRDprimitives.addBRD(t, m2);
		t = BRDprimitives.addBRD(t, m3);
		t = BRDprimitives.addBRD(t, m4);
		//BRDtree brd = BRDprimitives.addBRD(brd, m2);
		//BRDtree brd = BRDprimitives.addBRD(brd, m3);
		//BRDtree brd3 = BRDprimitives.addBRD(brd2, m4);
		Tools.printBriandais(t, 0);
	}

}
