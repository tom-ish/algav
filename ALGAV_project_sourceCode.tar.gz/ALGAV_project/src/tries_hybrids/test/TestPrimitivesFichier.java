package tries_hybrids.test;

import java.util.List;

import tools.Tools;
import tries_hybrids.HBDadvancedFunctions;
import tries_hybrids.HBDcomplexFunctions;
import tries_hybrids.HBDprimitives;
import tries_hybrids.HBDtree;

public class TestPrimitivesFichier {

	public static void main(String[] args) {
		List<String> l = Tools.getStringsFromFileHBD("Samples/tmp.txt");
		HBDtree t = null;
		t = HBDprimitives.addHBD(t,l);
		//Tools.printHybrid(t);

//		if(t.getInf()==null) System.out.println("fils inferieur null !");
//		if(t.getEq()==null) System.out.println("fils milieu null !");
		
		//t = HBDcomplexFunctions.equilibrage(t);
		//test lister par ordre alphabetique
		System.out.println("\n\n============================\n"
				+     "Lister en ordre alphabetique\n" +
				"============================\n");
		List<String> list = HBDadvancedFunctions.wordList(t);
		for(int i=0; i<list.size(); i++)
			System.out.println(list.get(i));

	}

}
