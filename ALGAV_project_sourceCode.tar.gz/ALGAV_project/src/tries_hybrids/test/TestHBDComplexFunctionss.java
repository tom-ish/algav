package tries_hybrids.test;

import java.util.List;

import tools.Tools;
import tries_briandais.BRDtree;
import tries_hybrids.HBDcomplexFunctions;
import tries_hybrids.HBDprimitives;
import tries_hybrids.HBDtree;

public class TestHBDComplexFunctionss {

	public static void main(String[] args) {
		String filename = "Samples/exemple_cours.txt";
		List<String> l = Tools.getStringsFromFileHBD(filename);
		HBDtree th = null;
		th = HBDprimitives.addHBD(th, l);
		BRDtree b = HBDcomplexFunctions.hybridToBRD(th);
		Tools.printBriandais(b, 0);
	}

}
