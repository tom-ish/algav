package tools.test;

import java.util.List;

import tools.Tools;

public class TestTools {

	public static void main(String[] args) {
//		System.out.println(Tools.head("abcd"));
//		System.out.println(Tools.tail("azerty"));
		String dir = "shakespeare";
		List<String> l = Tools.getFileNamesFromDirectory(dir);
		l.sort(null);
		
		for(String s : l)
			System.out.println(s);
//		
//		for(int i=0; i<l.size(); i++){
//			System.out.println(l.get(i));
//		}
//		System.out.println("Nombre de mots: "+l.size());
		//System.out.println("azerty".substring(1));
		
	
		
	}

}
