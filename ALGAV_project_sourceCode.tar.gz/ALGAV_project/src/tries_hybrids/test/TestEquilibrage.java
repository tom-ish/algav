package tries_hybrids.test;

import java.util.List;

import tools.Tools;
import tries_hybrids.HBDadvancedFunctions;
import tries_hybrids.HBDcomplexFunctions;
import tries_hybrids.HBDprimitives;
import tries_hybrids.HBDtree;

public class TestEquilibrage {

	public static void main(String[] args) {
		String filename = "Samples/tmp.txt";
		List<String> l = Tools.getStringsFromFileHBD(filename);
		HBDtree th = null;
		th = HBDprimitives.addHBD(th, l);
		//		l = HBDadvancedFunctions.wordList(th);
		//		for(String s : l) System.out.println(s);
		System.out.println(th.getCar());
		System.out.println(th.getSup().getCar());

		int hinf = HBDadvancedFunctions.height(th.getInf());
		int hsup = HBDadvancedFunctions.height(th.getSup());
		System.out.println("difference hauteur = "+ (hinf-hsup));
		
		
		th = HBDcomplexFunctions.equilibrage(th);
		
		System.out.println(th.getCar());
		System.out.println(th.getInf().getCar());
		
		System.out.println("Verification apres equilibrage: "+HBDcomplexFunctions.estEquilibre(th));
		hinf = HBDadvancedFunctions.height(th.getInf());
		hsup = HBDadvancedFunctions.height(th.getSup());
		System.out.println("Verification différence de hauteur apres equilibrage: "+(hinf-hsup) );
		l = HBDadvancedFunctions.wordList(th);
		for(String s : l) System.out.println(s);
		
		//		BRDtree b = HBDcomplexFunctions.hybridToBRD(th);
		//		Tools.printBriandais(b, 0);
	}

}

